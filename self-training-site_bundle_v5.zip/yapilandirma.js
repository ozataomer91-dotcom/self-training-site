// Firebase config ve başlatma
console.log('[cfg] yükleniyor');
const firebaseConfig = {
  apiKey: "AIzaSyAnMzCWonT_zLi0EnChIDYANBhDiiwmur4",
  authDomain: "self-training-128b5.firebaseapp.com",
  projectId: "self-training-128b5",
  storageBucket: "self-training-128b5.appspot.com", // düzeltildi
  messagingSenderId: "61732879565",
  appId: "1:61732879565:web:5a446fb76fa88f1103bd84"
};

// güvenlik: boş kalan bir alan olursa erken çık
if(!firebaseConfig.apiKey || firebaseConfig.apiKey.includes('PASTE_API_KEY')){
  console.warn('API KEY eksik/yanlış');
}
window.app = firebase.initializeApp(firebaseConfig);
window.auth = firebase.auth();
console.log('[cfg] hazır');
