Kendi Kendine Eğitim — Web demeti

1) Dosyaları GitHub Pages köküne koy.
2) 'yapilandirma.js' içinde kendi Firebase projenin değerleri zaten yazılı.
   storageBucket alanı appspot.com olacak şekilde düzeltildi.
3) Firebase Console → Authentication → Sign-in method → Email/Password: ENABLE.
4) Authentication → Settings → Authorized domains listesine
   ozataomer91-dotcom.github.io alanını ekle.
5) Aç: https://<kullanıcı>.github.io/<repo>/index.html
   Console'da uyarı yoksa giriş/kayıt çalışır.
