// giriş / kayıt / reset işlemleri
console.log('[auth] hazır');

function qs(x){ return document.querySelector(x); }
const emailInput = qs('#email');
const passInput  = qs('#pass');
const btnLogin   = qs('#btnLogin');
const btnSignup  = qs('#btnSignup');
const linkReset  = qs('#linkReset');
const note       = qs('#note');

async function login(){
  try{
    const em = emailInput.value.trim();
    const pw = passInput.value;
    if(!em || !pw){ note && (note.textContent='E‑posta ve şifre zorunlu.'); return; }
    const cred = await auth.signInWithEmailAndPassword(em, pw);
    location.href='dashboard.html';
  }catch(e){
    console.error(e);
    note && (note.innerHTML = '<span class="err">'+e.message+'</span>');
  }
}

async function signup(){
  try{
    const em = emailInput.value.trim();
    const pw = passInput.value;
    const cred = await auth.createUserWithEmailAndPassword(em, pw);
    note && (note.innerHTML = '<span class="ok">Hesap oluşturuldu. Girişe yönlendiriliyor…</span>');
    setTimeout(()=>location.href='index.html', 800);
  }catch(e){
    console.error(e);
    note && (note.innerHTML = '<span class="err">'+e.message+'</span>');
  }
}

async function reset(){
  try{
    const em = emailInput.value.trim();
    if(!em){ note && (note.textContent='Mail adresi gir.'); return; }
    await auth.sendPasswordResetEmail(em);
    note && (note.innerHTML = '<span class="ok">Şifre sıfırlama maili gönderildi.</span>');
  }catch(e){
    console.error(e);
    note && (note.innerHTML = '<span class="err">'+e.message+'</span>');
  }
}

btnLogin && btnLogin.addEventListener('click', login);
btnSignup && btnSignup.addEventListener('click', signup);
linkReset && linkReset.addEventListener('click', reset);
